#!/usr/bin/env Rscript

# RQ2 joint stage-interaction model. Every covariate is allowed to vary by
# stage, preventing stage structure in the controls from being absorbed by the
# surprisal interactions. Random slopes are maximal for the two surprisal
# predictors and their stage interactions.

suppressPackageStartupMessages({library(brms); library(dplyr)})
options(mc.cores = 4)

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(name, default) {
  hit <- grep(paste0("^", name, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", name, "="), "", hit[[1]])
}
data_dir <- normalizePath(
  get_arg("--data-dir", Sys.getenv("DISSERTATION_DATA_DIR", ".")),
  mustWork = TRUE
)
include_stoplight <- tolower(get_arg("--include-stoplight", "false")) == "true"
path <- function(...) file.path(data_dir, ...)

fix <- read.csv(path("fixation_durations_word.csv"), stringsAsFactors = FALSE)
nmt <- read.csv(path("nmt_surprisal_soft_word.csv"), stringsAsFactors = FALSE)
mono <- read.csv(path("monolingual_surprisal_word.csv"), stringsAsFactors = FALSE)
freq <- read.table(path("subtlex_us.csv"), sep = "\t", header = TRUE,
                   stringsAsFactors = FALSE, quote = "") %>%
  transmute(word_lower = tolower(trimws(Word)), log10_freq = Lg10WF)

sentence_lengths <- nmt %>%
  group_by(sentence_id) %>%
  summarise(sentence_length = max(word_index) + 1, .groups = "drop")
predictors <- nmt %>%
  left_join(sentence_lengths, by = "sentence_id") %>%
  mutate(
    word_length = nchar(word),
    word_position = word_index / (sentence_length - 1),
    word_lower = tolower(trimws(word))
  ) %>%
  left_join(freq, by = "word_lower") %>%
  left_join(
    mono %>% select(sentence_id, word_index,
                    mono_surprisal = surprisal_sum),
    by = c("sentence_id", "word_index")
  ) %>%
  select(sentence_id, word_index, word_length, word_position,
         nmt_surprisal = surprisal_soft, mono_surprisal, log10_freq)

data <- fix %>%
  filter(stage %in% c("translate", "read")) %>%
  left_join(predictors, by = c("sentence_id", "word_index")) %>%
  mutate(
    log_tfd = log(total_fixation_duration_ms),
    ambiguity = factor(ambiguity),
    condition = as.integer(stage == "translate")
  ) %>%
  filter(!is.na(nmt_surprisal), !is.na(mono_surprisal),
         !is.na(log10_freq))
if (!include_stoplight) {
  data <- data %>%
    anti_join(tibble(sentence_id = "S003", word_index = 3L),
              by = c("sentence_id", "word_index"))
}

z <- function(x) (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE)
data <- data %>% mutate(
  c_nmt = z(nmt_surprisal), c_mono = z(mono_surprisal),
  c_wlen = z(word_length), c_wpos = z(word_position),
  c_freq = z(log10_freq)
)
cat(sprintf(
  "Pooled N=%d (translate %d, read %d; stoplight %s)\n",
  nrow(data), sum(data$condition == 1), sum(data$condition == 0),
  ifelse(include_stoplight, "included", "excluded")
))

priors <- c(
  prior(normal(0, 1), class = b),
  prior(normal(6, 1), class = Intercept),
  prior(exponential(1), class = sd),
  prior(exponential(1), class = sigma),
  prior(lkj(2), class = cor)
)
random_effects <- paste0(
  "(1 + condition + c_nmt + c_mono + condition:c_nmt + ",
  "condition:c_mono | participant) + ",
  "(1 + condition + c_nmt + c_mono + condition:c_nmt + ",
  "condition:c_mono | sentence_id)"
)
formula <- as.formula(paste(
  "log_tfd ~ condition * (c_wlen + c_wpos + c_freq + ambiguity +",
  "c_nmt + c_mono) +", random_effects
))

model <- brm(
  formula, data = data, prior = priors,
  control = list(adapt_delta = 0.99, max_treedepth = 15),
  chains = 4, iter = 4000, warmup = 2000,
  save_pars = save_pars(all = TRUE), silent = 2, refresh = 0
)
dir.create(path("brm_cache"), showWarnings = FALSE)
cache_name <- if (include_stoplight) {
  "rq2rob_joint_stoplight.rds"
} else {
  "rq2_joint_maximal_v2.rds"
}
saveRDS(model, path("brm_cache", cache_name))

print(round(fixef(model), 4))
stage_slopes <- hypothesis(
  model,
  c(
    nmt_read = "c_nmt = 0",
    nmt_translate = "c_nmt + condition:c_nmt = 0",
    mono_read = "c_mono = 0",
    mono_translate = "c_mono + condition:c_mono = 0"
  )
)
print(stage_slopes)
divergences <- sum(
  subset(nuts_params(model), Parameter == "divergent__")$Value
)
cat(sprintf(
  "Rhat max: %.4f | divergences: %d\n",
  max(rhat(model), na.rm = TRUE), divergences
))
